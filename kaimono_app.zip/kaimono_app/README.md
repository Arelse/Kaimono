# Kaimono

A Flutter skeleton for a multi-medium (manga / anime / novel) reader with
a pluggable, extension-based source system — architecturally inspired by
Komikku/Mihon/Mangayomi, not a copy of any of their UIs.

## What's actually here

- `lib/models/` — `Source` interface, unified `Entry`/`EntryChunk` model
  shared across manga, anime, and novels.
- `lib/services/js_source.dart` — the extension engine: loads a `.js`
  module per source at runtime via `flutter_js` and bridges HTTP calls
  through Dio, so extensions are just JS files, not compiled Dart.
- `lib/services/extension_manager.dart` — repo index fetching,
  install/uninstall, Riverpod state.
- `lib/screens/` — Library (tabbed by content type), Browse, Extensions
  manager, Updates feed stub, Entry detail (synopsis + chunk list), and
  three consumption screens: `manga_reader_screen.dart` (paged + webtoon
  image reader), `novel_reader_screen.dart` (text reader), and
  `player_screen.dart` (video_player/chewie playback with quality picker).
  Entry detail routes to the right one automatically based on
  `Entry.type`.
- `assets/sample_repo/` — a working demo repo (`index.json` +
  `demo_manga.js`) showing the exact contract a real extension implements.

## Important: extension compatibility, honestly

This does **not** load Mihon/Keiyoshi `.apk` extensions or Mangayomi's
bundled source packages directly — those are compiled for their own
runtimes (JVM bytecode for Mihon forks; Mangayomi ships its own Dart-side
source bridge tied to its app). True drop-in compatibility with either
ecosystem would mean re-implementing their loader internals, which is a
large, ecosystem-specific effort on its own.

What this gives you instead: a source contract (`Source` /
`js_source.dart`) deliberately shaped like Mihon's method set
(popular/latest/search/details/chapters/pages) and Mangayomi's JS source
API, so **porting the scraping logic** of an existing open-source
extension into this format is a translation job per-source — not a
redesign, and not automatic.

## Next steps to make this real

1. `flutter create .` in this directory to generate platform folders
   (android/ios/etc.), then `flutter pub get`.
2. Run `dart run build_runner build` for Isar's generated code once you
   add `@collection` models for library/history persistence.
3. Write 2–3 real source `.js` files (start with a manga site with a
   simple HTML structure) using `httpGet()` + the `html` package's
   parser, following `demo_manga.js`'s contract.
4. Host your own `index.json` repo and point
   `ExtensionManager.repos` at it.
5. Build out the reader (paged/webtoon view for manga, text view for
   novels) and player (video_player/chewie, already in pubspec) screens —
   not included yet.

## Not included (by design, given scope)

- Isar persistence wiring (models exist, storage layer doesn't yet —
  library/favorite toggle and read/watch history are currently in-memory
  only, see TODOs in `library_screen.dart` and `entry_detail_screen.dart`)
- Background update-checking job
- Tracking (MAL/AniList) integration
- Downloads-for-offline
- Search bar within a single source's browse view (currently
  popular-list only — search() exists on `Source` but isn't wired to UI)

## Building the APK

This container can't produce a compiled APK (no Android SDK, no network
access to fetch packages). On your own machine, from the unzipped
project folder:

```
flutter create . --platforms=android
flutter pub get
flutter build apk --debug
```

The APK lands at `build/app/outputs/flutter-apk/app-debug.apk`. Use
`flutter build apk --release` once you're ready to sign a release build
(requires setting up a keystore — see Flutter's official signing docs).
